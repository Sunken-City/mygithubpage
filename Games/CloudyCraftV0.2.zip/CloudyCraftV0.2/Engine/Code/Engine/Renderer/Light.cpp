#include "Engine/Renderer/Light.hpp"

Light::Light()
{

}

Light::~Light()
{

}
