#include "stdafx.h"
#include "Serializeable.h"

int Serializeable::null = 0;
int Serializeable::notNull = 1;