//-----------------------------------------------------------------------------------------------
// Time.hpp
//
#pragma once
#ifndef included_Time
#define included_Time

//---------------------------------------------------------------------------
double GetCurrentTimeSeconds();

#endif
