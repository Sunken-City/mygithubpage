#pragma once

/* 
* 0 - Simple Tracking
* 1 - Verbose
* 2 - Insanely Verbose (Every new, every free)
* Not defined = no memory tracking
*/
//#define TRACK_MEMORY 1