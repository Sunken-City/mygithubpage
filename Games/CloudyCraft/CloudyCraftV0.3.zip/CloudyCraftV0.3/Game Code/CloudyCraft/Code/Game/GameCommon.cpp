#include "Game\GameCommon.hpp"

int g_frameNumber = 0;
bool g_renderDebug = true;
